package com.desginpattern.desginpatternproj.model;

public class NumberModel {
    public int findGreatest(int num1, int num2) {
        return Math.max(num1, num2);
    }
}

