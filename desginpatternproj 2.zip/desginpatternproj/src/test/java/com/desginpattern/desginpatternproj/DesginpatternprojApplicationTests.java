package com.desginpattern.desginpatternproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesginpatternprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
